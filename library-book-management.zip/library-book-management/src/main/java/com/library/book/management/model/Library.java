package com.library.book.management.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Library {
	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "status_name")
	private String status;

	@Column(name = "borrower_name")
	private String borrower;

	@Column(name = "library_Name")
	private String libraryName;

	@Column(name = "borrow_Date")
	private Date borrowDate;

	@OneToMany(mappedBy = "library")
	private List<Book> books;

	// lombok dependency can be used without generating the below getter and setter
	// by placing the jar
	// eclipse in the eclipse path and configuring the eclipse.ini file

	public String getLibraryName() {
		return libraryName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLibraryName(String libraryName) {
		this.libraryName = libraryName;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBorrower() {
		return borrower;
	}

	public void setBorrower(String borrower) {
		this.borrower = borrower;
	}

	public Date getBorrowDate() {
		return borrowDate;
	}

	public void setBorrowDate(Date borrowDate) {
		this.borrowDate = borrowDate;
	}

	public Library(Long id, String status, String borrower, String libraryName, Date borrowDate, List<Book> books) {
		super();
		this.id = id;
		this.status = status;
		this.borrower = borrower;
		this.libraryName = libraryName;
		this.borrowDate = borrowDate;
		this.books = books;
	}

	public Library() {
	}
}
