package com.library.book.management;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.library.book.management.model.Book;
import com.library.book.management.model.Library;
import com.library.book.management.repository.LibraryBookManagementRepository;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LibraryBookManagementController {

	private Logger log = org.slf4j.LoggerFactory.getLogger(this.getClass());

	@Autowired
	LibraryBookManagementRepository libraryBookRepository;

	// TODO-- Alternatively we can use below entityManager class for all the
	// Transaction
	// by annotating with @Transactional annotation at method or class

	/*
	 * @PersistenceContext EntityManager entityManager;
	 */

	/**
	 * Method to get all the all the books for library
	 * 
	 * @return
	 */

	@GetMapping(path = "/fetchLibraryBook/id/{id}")
	public List<Book> retriveBook(@PathVariable Long id) {
		log.info("retriveAllBook():methods start");

		Assert.notNull(id, "Library id id cannot be empty");

		Optional<Library> library = libraryBookRepository.findById(id);

		List<Book> books = library.get().getBooks();

		// TODO-- Alternatively we can use entityManager all the Transaction

		/*
		 * entityManager.find(Book.class, 102); //to fetch the records.
		 */
		return books;
	}

	/**
	 * Method to get save the library and the books
	 * 
	 * @return
	 */

	@PostMapping(path = "/createBooksLibrary")
	public void createBooksLibrary(@RequestBody Library library) {
		log.info("createBooksLibrary():methods start");

		Assert.notNull(library.getLibraryName(), "Library Name cannot be empty");
		Assert.notNull(library.getStatus(), "Book Status cannot be empty");

		Library libry = new Library();
		libry.setLibraryName(library.getLibraryName());
		libry.setBorrower(library.getBorrower());
		libry.setBorrowDate(new Date());
		libry.setStatus(library.getStatus());

		List<Book> books = library.getBooks().stream().collect(Collectors.toList());

		libry.setBooks(books);

		// Alternatively we can pass the below request in Java Obejct or json request in
		// the request boby from the soapUI/Postman

		/*
		 * { "status": "Avaiable", "borrower": "Rao", "libraryName": "RT Nagar",
		 * "borrowDate": "2020-06-11T07:00:00.000+0000", "books": [ { "name": "Civil",
		 * "bookAuthor": "Rao", "serialNo": 65 } ] } --actual request
		 */

		libraryBookRepository.save(libry);

		// TODO-- Alternatively we can use below entityManager class all the Transaction
		/*
		 * entityManager.persist(book); //toSave and update the records.
		 */

		log.info("createBooksLibrary():methods ends");
	}

	/**
	 * Method to update the library and book details
	 * 
	 * @return
	 */

	@PutMapping(path = "/updateLibraryBook/id/{id}")
	public void updateLibraryBook(@PathVariable Long id, @RequestBody Library libraryReq) {
		log.info("updateLibraryBook():methods start");

		Assert.notNull(libraryReq.getLibraryName(), "Library Name cannot be empty");

		Optional<Library> library = libraryBookRepository.findById(id);

		Library lib = library.get();
		
		lib.setLibraryName(libraryReq.getLibraryName());
	
		libraryBookRepository.save(lib);

		log.info("updateBook():methods ends");
	}

	/**
	 * As per the 3 rd point in the use case- Method to get all the library and its books
	 * 
	 * @return
	 */

	@GetMapping(path = "/fetchLibraries")
	public List<Library> retriveAllLibraries() {
		log.info("retriveAllBook():methods start");

		return libraryBookRepository.findAll();
	}
}
