package com.library.book.management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Book {
	@Id
	@GeneratedValue // auto generated primary key
	private Long id;

	@Column(name = "book_name") // table column will be generated with this name.
	private String name;

	@Column(name = "book_authore")
	private String bookAuthor;

	@Column(name = "book_serialno")
	private int serialNo;

	
	private int library_id;

	// lombok dependency can be used without generating the below getter and setter
	// by placing the jar
	// eclipse in the eclipse path and configuring the eclipse.ini file

	public int getLibrary_id() {
		return library_id;
	}

	public void setLibrary_id(int library_id) {
		this.library_id = library_id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name = "library_id", referencedColumnName = "id",insertable=false, updatable=false)
	private Library library;

	
	public Library getLibrary() {
		return library;
	}

	public void setLibrary(Library library) {
		this.library = library;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public Book() {
	}

}
