package com.library.book.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.library.book.management.model.Library;
@Repository
public interface LibraryBookManagementRepository extends JpaRepository<Library, Long>{
	
}
