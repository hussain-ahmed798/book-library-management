Insert into library(id,status_name,borrower_name,library_Name,borrow_Date) values (1000,'Opened','Rao','Indira Priyadarshini Library for Children, Cubbon Park',sysdate());
Insert into library(id,status_name,borrower_name,library_Name,borrow_Date) values (1001,'Closed','Chetan','City Library, Double Road',sysdate());
Insert into library(id,status_name,borrower_name,library_Name,borrow_Date) values (1002,'Opened','Raju','Library in Koramangala',sysdate());
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (105,'Civil','Rao',65,1000);
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (106,'Maths','James',75,1000);
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (107,'Electrical','Venkata Rao',65,1001);
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (108,'Botany','James willam',75,1001);
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (109,'Zoology','Raja Rao',65,1002);
Insert into book(id,book_name,book_authore,book_serialno,library_id) values (110,'Chemistry','James andreson',75,1002);